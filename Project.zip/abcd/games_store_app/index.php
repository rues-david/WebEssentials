<html>

<head>
<title> Online Video Game Store Database</title>
</head>

<body>
<h2>Game Store Database Menu</h2>

<h3>Products</h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view_products.php">View All Products</a> (You can Edit or Delete Products through this view, as well.)<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="add_product.php">Add a Product</a><br/>



<h3>Customers</h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view_customers.php">View All Customers</a> (You can Edit or Delete Customers through this view, as well.)<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="add_customer.php">Add a Customer</a><br/>


<h3>Customer Orders</h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view_customer_orders.php">View Orders</a> (You can Edit or Delete Customer Orders through this view, as well.)<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="add_order.php">Make an Order</a><br/>



</body>


<html>




